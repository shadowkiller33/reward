from LHS import LHS
from datasets import load_dataset
import nlpaug.augmenter.char as nac
import nlpaug.augmenter.word as naw
import nlpaug.augmenter.sentence as nas
import nlpaug.flow as nafc

from nlpaug.util import Action

model = LHS(model_name_or_path="princeton-nlp/sup-simcse-roberta-base", threshold=0.02, LHS_num=200)
sentence_list = []
eval_dataset = load_dataset("lvwerra/stack-exchange-paired", data_dir="data/evaluation", split="train").select(range(5000))
train_dataset = load_dataset("lvwerra/stack-exchange-paired", data_dir="data/reward", split="train").select(range(1000))
for x in eval_dataset['response_j']:
    sentence_list.append(x)
for x in train_dataset['response_j']:
    sentence_list.append(x)
sentence_list = list(set(sentence_list))
model.build_index(sentence_list,batch_size=256, faiss_fast=True)

L = []
A = []
score = []
for text in sentence_list[:1000]:
    list = []
    length = len(text.split())
    aug = naw.SpellingAug(aug_max=int(0.054*length))
    augmented_texts = aug.augment(text, n=3)
    for augmented_text in augmented_texts:
        L.append(augmented_text)
        A.append(text)

retrieval = []
results = model.search(L, top_k=1)
for i, x in enumerate(results):
    retrieval.append(x[0][0])
    score.append(x[0][0]==A[i])
print(sum(score)/len(score))



# list.append((text, augmented_text, results))
# score.append(text==results)
# L.append(list)
# print(sum(score)/len(score))
a = 1



